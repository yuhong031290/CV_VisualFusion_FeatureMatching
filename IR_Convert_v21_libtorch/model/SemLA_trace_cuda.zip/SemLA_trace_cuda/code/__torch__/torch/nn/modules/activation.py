class ReLU(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  def forward(self: __torch__.torch.nn.modules.activation.ReLU,
    argument_1: Tensor) -> Tensor:
    return torch.relu_(argument_1)
class Sigmoid(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  def forward(self: __torch__.torch.nn.modules.activation.Sigmoid,
    argument_1: Tensor) -> Tensor:
    return torch.sigmoid(argument_1)
  def forward1(self: __torch__.torch.nn.modules.activation.Sigmoid,
    argument_1: Tensor) -> Tensor:
    return torch.sigmoid(argument_1)
class GELU(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  def forward(self: __torch__.torch.nn.modules.activation.GELU,
    argument_1: Tensor) -> Tensor:
    return torch.gelu(argument_1)
