class LayerNorm(Module):
  __parameters__ = ["weight", "bias", ]
  __buffers__ = []
  weight : Tensor
  bias : Tensor
  training : bool
  _is_full_backward_hook : Optional[bool]
  def forward(self: __torch__.torch.nn.modules.normalization.___torch_mangle_211.LayerNorm,
    argument_1: Tensor) -> Tensor:
    bias = self.bias
    weight = self.weight
    message = torch.layer_norm(argument_1, [256], weight, bias)
    return message
  def forward1(self: __torch__.torch.nn.modules.normalization.___torch_mangle_211.LayerNorm,
    argument_1: Tensor) -> Tensor:
    bias = self.bias
    weight = self.weight
    message = torch.layer_norm(argument_1, [256], weight, bias)
    return message
