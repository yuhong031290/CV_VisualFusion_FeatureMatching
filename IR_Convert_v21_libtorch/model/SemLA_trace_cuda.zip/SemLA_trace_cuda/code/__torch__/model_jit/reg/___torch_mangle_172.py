class CrossModalAttention(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  qkv : __torch__.torch.nn.modules.linear.___torch_mangle_163.Linear
  proj_out : __torch__.torch.nn.modules.linear.___torch_mangle_164.Linear
  norm1 : __torch__.torch.nn.modules.normalization.___torch_mangle_165.LayerNorm
  norm2 : __torch__.torch.nn.modules.normalization.___torch_mangle_166.LayerNorm
  mlp : __torch__.model_jit.utils.___torch_mangle_171.MLP2
  def forward(self: __torch__.model_jit.reg.___torch_mangle_172.CrossModalAttention,
    argument_1: Tensor,
    argument_2: Tensor) -> Tensor:
    mlp = self.mlp
    norm2 = self.norm2
    proj_out = self.proj_out
    qkv = self.qkv
    norm1 = self.norm1
    _0 = (qkv).forward((norm1).forward(argument_1, ), )
    input = torch.einsum("nl, nlc -> nlc", [argument_2, _0])
    input0 = torch.add((proj_out).forward(input, ), argument_1)
    _1 = (mlp).forward((norm2).forward(input0, ), )
    return torch.add(input0, _1)
