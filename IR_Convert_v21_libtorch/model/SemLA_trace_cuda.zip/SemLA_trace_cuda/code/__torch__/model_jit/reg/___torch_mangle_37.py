class JConv(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  feat_trans : __torch__.model_jit.utils.___torch_mangle_26.CBR
  dwconv : __torch__.model_jit.utils.___torch_mangle_31.DWConv
  norm : __torch__.torch.nn.modules.batchnorm.___torch_mangle_32.BatchNorm2d
  mlp : __torch__.model_jit.utils.___torch_mangle_36.MLP
  def forward(self: __torch__.model_jit.reg.___torch_mangle_37.JConv,
    argument_1: Tensor) -> Tensor:
    mlp = self.mlp
    norm = self.norm
    dwconv = self.dwconv
    feat_trans = self.feat_trans
    _0 = (feat_trans).forward(argument_1, )
    input = torch.add(_0, (dwconv).forward(_0, ))
    _1 = (mlp).forward((norm).forward(input, ), )
    return torch.add(input, _1)
