class MLP2(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  fc : __torch__.torch.nn.modules.container.___torch_mangle_170.Sequential
  def forward(self: __torch__.model_jit.utils.___torch_mangle_171.MLP2,
    argument_1: Tensor) -> Tensor:
    fc = self.fc
    return (fc).forward(argument_1, )
