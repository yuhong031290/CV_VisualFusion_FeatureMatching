class MLP(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  conv1 : __torch__.torch.nn.modules.conv.___torch_mangle_78.Conv2d
  act : __torch__.torch.nn.modules.activation.___torch_mangle_79.ReLU
  conv2 : __torch__.torch.nn.modules.conv.___torch_mangle_80.Conv2d
  def forward(self: __torch__.model_jit.utils.___torch_mangle_81.MLP,
    argument_1: Tensor) -> Tensor:
    conv2 = self.conv2
    act = self.act
    conv1 = self.conv1
    _0 = (act).forward((conv1).forward(argument_1, ), )
    return (conv2).forward(_0, )
